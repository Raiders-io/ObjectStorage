import { Injectable } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import type { Readable } from 'node:stream'
import type { Env } from '../config/env.js'
import { FsDriver } from './fs.driver.js'
import { S3Driver } from './s3.driver.js'
import type { StorageDriver } from './storage-driver.js'

/** Thin facade over the configured disk (`DRIVE_DISK=s3|fs`), replacing @adonisjs/drive. */
@Injectable()
export class StorageService implements StorageDriver {
  private readonly driver: StorageDriver
  readonly bucket: string

  constructor(config: ConfigService<Env, true>) {
    this.bucket = config.get('S3_BUCKET', { infer: true }) ?? 'local'
    if (config.get('DRIVE_DISK', { infer: true }) === 'fs') {
      this.driver = new FsDriver(config.get('FS_STORAGE_PATH', { infer: true }))
    } else {
      this.driver = new S3Driver({
        accessKeyId: config.get('AWS_ACCESS_KEY_ID', { infer: true })!,
        secretAccessKey: config.get('AWS_SECRET_ACCESS_KEY', { infer: true })!,
        region: config.get('AWS_REGION', { infer: true })!,
        bucket: config.get('S3_BUCKET', { infer: true })!,
        endpoint: config.get('S3_ENDPOINT', { infer: true })!,
      })
    }
  }

  exists(key: string): Promise<boolean> {
    return this.driver.exists(key)
  }
  put(key: string, body: Buffer, contentType?: string): Promise<void> {
    return this.driver.put(key, body, contentType)
  }
  getStream(key: string): Promise<Readable> {
    return this.driver.getStream(key)
  }
  delete(key: string): Promise<void> {
    return this.driver.delete(key)
  }
  deleteAll(prefix: string): Promise<void> {
    return this.driver.deleteAll(prefix)
  }
}
