import type { Readable } from 'node:stream'

export interface StorageDriver {
  exists(key: string): Promise<boolean>
  put(key: string, body: Buffer, contentType?: string): Promise<void>
  getStream(key: string): Promise<Readable>
  delete(key: string): Promise<void>
  deleteAll(prefix: string): Promise<void>
}
