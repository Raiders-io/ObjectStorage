import { createReadStream } from 'node:fs'
import { mkdir, rm, stat, writeFile } from 'node:fs/promises'
import { dirname, join, resolve, sep } from 'node:path'
import type { Readable } from 'node:stream'
import type { StorageDriver } from './storage-driver.js'

export class FsDriver implements StorageDriver {
  private readonly root: string

  constructor(root: string) {
    this.root = resolve(root)
  }

  private path(key: string): string {
    const full = resolve(join(this.root, key))
    if (full !== this.root && !full.startsWith(this.root + sep)) {
      throw new Error('Invalid storage key')
    }
    return full
  }

  async exists(key: string): Promise<boolean> {
    try {
      return (await stat(this.path(key))).isFile()
    } catch {
      return false
    }
  }

  async put(key: string, body: Buffer): Promise<void> {
    const file = this.path(key)
    await mkdir(dirname(file), { recursive: true })
    await writeFile(file, body)
  }

  async getStream(key: string): Promise<Readable> {
    return createReadStream(this.path(key))
  }

  async delete(key: string): Promise<void> {
    await rm(this.path(key), { force: true })
  }

  async deleteAll(prefix: string): Promise<void> {
    await rm(this.path(prefix), { recursive: true, force: true })
  }
}
